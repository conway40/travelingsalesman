Title: The Traveling Salesman
Description: 
	This application will allow a salesperson to track their travels as they 
	buy and sell their products. This application will also take advantage of the MVC 
	design pattern and focus on a clear separation of concerns.
Application Type: Console
Author: Caitlin Conway
Dated Created: 9/13/2017
Last Modified: 9/13/2017